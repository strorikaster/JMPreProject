/**
 * Created by A.Zotov on 12.04.2017.
 */
public class TypeOfNumbers {
    public static void main(String[] args) {
        double a = 24.0;
        double b = 0.1;

        System.out.println("Multiply a and b: " + a*b);
        System.out.println("Double - max value: " + Double.MAX_VALUE + " Double - min value: " + Double.MIN_VALUE);
    }
}
