/**
 * Created by A.Zotov on 13.04.2017.
 */

public class Regexp {

            public static void main(String[] args)
            {
                String str = "Петя заработал 4300 рублей, Вася заработал 3530, Катя заработала 2050 рублей";

                String strArr[] = ((str.replaceAll("[^0-9/s0-9]+", "//s"))).replaceFirst("//s", "").split("//s");

                Integer cashMoney[] = new Integer[strArr.length];

                int sum = 0;
                for(int i=0; i < strArr.length;i++){
                  cashMoney[i] = Integer.parseInt(strArr[i]);
                    sum += cashMoney[i];

                }

                System.out.println("Сумма заработанных денег " + sum + " рублей");
            }


}
